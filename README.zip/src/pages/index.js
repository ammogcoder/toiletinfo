import React from 'react';
import repo from '../logic/repo.js';
import toilet from '../logic/toilet.js'; 

const Home = () => {
//    let t= new toilet(); 
// 	t.country ='';
// 	//console.log(t);

// 	var r= new repo();
// 	console.log(r);
// 	r.addrecord(t);

return (
	<div
	style={{
		display: 'flex',
		justifyContent: 'Right',
		alignItems: 'Right',
		height: '100vh'
	}}
	>
	<h1>Welcome to GeeksforGeeks</h1>
	</div>
);
};

export default Home;

